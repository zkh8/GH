package com.example.gh.bean;

import java.util.ArrayList;

public class UserInfo {

    public int id;
    public String phone;
    public int login_at;


    public UserInfo() {

        id = 0;
        phone = "";
        login_at = 0;
    }
}
